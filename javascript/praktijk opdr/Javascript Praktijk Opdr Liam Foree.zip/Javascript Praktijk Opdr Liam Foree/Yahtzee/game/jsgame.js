var images = [
'images/dice1.png',
'images/dice2.png',
'images/dice3.png',
'images/dice4.png',
'images/dice5.png',
'images/dice6.png',];

let dice1 = {
    element: document.getElementById("dice1"),
    hold: false,
    score: 0,
}

let dice2 = {
    element: document.getElementById("dice2"),
    hold: false,
    score: 0,
}

let dice3 = {
    element: document.getElementById("dice3"),
    hold: false,
    score: 0,
}

let dice4 = {
    element: document.getElementById("dice4"),
    hold: false,
    score: 0,
}

let dice5 = {
    element: document.getElementById("dice5"),
    hold: false,
    score: 0,
}

let dice = [dice1, dice2, dice3, dice4, dice5];

for(let j = 0; j < dice.length; j++){
    dice[j].element.addEventListener("click", function(){Hold(j);});
}

var score = 0;
var rollsleft = 3;
var DiceScore = 0;

var total;
var bonus = 35;

function roll_images(){
    var random;
    score = 0;
    rollsleft--;
    
    document.getElementById('roll').innerHTML = "Roll || Rolls Left: " + rollsleft; //rolls left
    if(rollsleft <= 0){
        document.getElementById('roll').innerHTML = "No more rolls left";
       
    }
    if(rollsleft >= 0){
    for(let i = 0;i  < dice.length;i++){  //dices roll
        if(!dice[i].hold){
        random = Math.floor(Math.random() * 6);
        dice[i].element.src = images[random];
        dice[i].score = (random += 1);
        }
        score = dice[i].score + score;
    }
    document.getElementById('score').innerHTML = "Current Total: " + score;
    }
}

function Hold(number){
    dice[number].hold = !dice[number].hold;
    if(dice[number].hold){
        dice[number].element.style.border = "3px solid red"
    }else{
        dice[number].element.style.border = "3px solid transparent"
    }
}

function scorecheck(el){
    console.log("Pressed: " + el.id);
    const DiceAmount = dice.filter(die => die.score == el.id).length;
    console.log("Total: " + DiceAmount * el.id);
    el.innerHTML = (DiceAmount * el.id);
    total = document.getElementById('totalTop').innerHTML;
    document.getElementById('totalTop').innerHTML = parseInt(total) + DiceAmount * parseInt(el.id);
    document.getElementById('uppertotal').innerHTML = parseInt(total) + DiceAmount * parseInt(el.id);
    if(total >= 63){
        document.getElementById('bonus').innerHTML = parseInt(bonus);
        document.getElementById('uppertotal').innerHTML = parseInt(total) + DiceAmount * parseInt(el.id) + parseInt(bonus);
        document.getElementById('totalalltop').innerHTML = parseInt(uppertotal.innerHTML);
    }
    
    el.style.backgroundColor = "red";
    el.classList.remove('grow');
    el.classList.add('text');
    everything();
    endTurn();
}

function everything(){
    bottomcheck();
    document.getElementById('totalalltop').innerHTML = document.getElementById('uppertotal').innerHTML;
    document.getElementById('totalallbottom').innerHTML = document.getElementById('totalbottom').innerHTML;
    document.getElementById('grandtotal').innerHTML = parseInt(document.getElementById('totalalltop').innerHTML) + parseInt(document.getElementById('totalallbottom').innerHTML);
}

function bottomcheck(){
    var listtotal = 0;

    var totalbottomlist = ['7', '8', '9', '10', '11', '12', '13'];
    for(let i = 0; i < totalbottomlist.length;i++){
        document.getElementById(totalbottomlist[i]).innerHTML;
        console.log(document.getElementById(totalbottomlist[i]).innerHTML);
        listtotal += parseInt(document.getElementById(totalbottomlist[i]).innerHTML);
    }

    document.getElementById('totalbottom').innerHTML = listtotal;
}

function threecheck(el){
    let dicescorecheck = 1;
    let remember = 0;

for(let t = 0; t < 6; t++){
    remember = 0;
    for(let q = 0; q < 5; q++){
        if(dicescorecheck == dice[q].score){
            remember++;
        }
    }
    if(remember == 3){
       document.getElementById('7').innerHTML = parseInt(score);
       document.getElementById('7').style.backgroundColor = "red";
       document.getElementById('7').classList.remove('grow');
       document.getElementById('7').classList.add('text');
       everything();
       endTurn();
    }
         dicescorecheck++;
    }
    }

    function fourcheck(){
        let dicescorecheck = 1;
        let remember = 0;
    
    for(let t = 0; t < 6; t++){
        remember = 0;
        for(let q = 0; q < 5; q++){
            if(dicescorecheck == dice[q].score){
                remember++;
            }
        }
        if(remember == 4){
           document.getElementById('8').innerHTML = parseInt(score);
           document.getElementById('8').style.backgroundColor = "red";
           document.getElementById('8').classList.remove('grow');
           document.getElementById('8').classList.add('text');
           everything();
           endTurn();
        }
             dicescorecheck++;
        }
        }

        
    function yahtzee(){
        let dicescorecheck = 1;
        let remember = 0;
    
    for(let t = 0; t < 6; t++){
        remember = 0;
        for(let q = 0; q < 5; q++){
            if(dicescorecheck == dice[q].score){
                remember++;
            }
        }
        if(remember == 5){
           document.getElementById('12').innerHTML = parseInt(score);
           document.getElementById('12').style.backgroundColor = "red";
           document.getElementById('12').classList.remove('grow');
           document.getElementById('12').classList.add('text');
           everything();
           endTurn();
        }
             dicescorecheck++;
        }
        }


    function fullhouse(){
        let dicescorecheck = 1;
        let dicescorecheck2 = 1;
        let remember = 0;
        let remember2 = 0;
    
        for(let t = 0; t < 6; t++){
        remember = 0;
        for(let q = 0; q < 5; q++){
            if(dicescorecheck == dice[q].score){
                remember++;
            }
        }
        if(remember == 3){
            for(let f = 0; f < 6; f++){
                remember2 = 0;
                for(let b = 0; b < 5; b++){
                    if(dicescorecheck != dicescorecheck2){
                        
                        if(dicescorecheck2 == dice[b].score){
                            remember2++;
                        }
                    }
                }
            dicescorecheck2++;
           
                if(remember == 3 && remember2 == 2){
                    document.getElementById('9').innerHTML = parseInt('25');
                    document.getElementById('9').style.backgroundColor = "red";
                    document.getElementById('9').classList.remove('grow');
                    document.getElementById('9').classList.add('text');
                    everything();
                    endTurn();
                    }
 
                }
            }
            dicescorecheck++;
        }
    }

function smallStraight(){
    let temps = "";
    var temp = ['0','0','0','0','0','0'];
    for(let i = 0; i < 5; i++){
       if(temp[dice[i].score-1] == 0){
           temp[dice[i].score-1] = 1;
       }
    }
    for(let i = 0; i < 6;i++){
        temps += temp[i];
    }
    console.log(temps);
    if(temps == "011110" || temps == "001111" || temps == "111100"){
    console.log("small straight");
    document.getElementById('10').innerHTML = "30";
    document.getElementById('10').style.backgroundColor = "red";
    document.getElementById('10').classList.remove('grow');
    document.getElementById('10').classList.add('text');
    everything();
    endTurn();
    }
}

function largeStraight(){
    let temps = "";
    var temp = ['0','0','0','0','0','0'];
    for(let i = 0; i < 5; i++){
       if(temp[dice[i].score-1] == 0){
           temp[dice[i].score-1] = 1;
       }
    }
    for(let i = 0; i < 6;i++){
        temps += temp[i];
    }
    console.log(temps);
    if(temps == "011110" || temps == "011111" || temps == "111110"){
    console.log("large straight");
    document.getElementById('11').innerHTML = "40";
    document.getElementById('11').style.backgroundColor = "red";
    document.getElementById('11').classList.remove('grow');
    document.getElementById('11').classList.add('text');
    everything();
    endTurn();
    }
}

function chance(){
    document.getElementById('13').innerHTML = score;
    document.getElementById('13').style.backgroundColor = "red";
    document.getElementById('13').classList.remove('grow');
    document.getElementById('13').classList.add('text');
    everything();
    endTurn();
}


function endTurn(){
    dice[0].element.src = 'images/qm.png';
    dice[1].element.src = 'images/qm.png';
    dice[2].element.src = 'images/qm.png';
    dice[3].element.src = 'images/qm.png';
    dice[4].element.src = 'images/qm.png';

    dice[0].score = 0;
    dice[1].score = 0;
    dice[2].score = 0;
    dice[3].score = 0;
    dice[4].score = 0;

    dice[0].hold = false;
    dice[1].hold = false;
    dice[2].hold = false;
    dice[3].hold = false;
    dice[4].hold = false;
    
    dice[0].element.style.border = "3px solid transparent";
    dice[1].element.style.border = "3px solid transparent";
    dice[2].element.style.border = "3px solid transparent";
    dice[3].element.style.border = "3px solid transparent";
    dice[4].element.style.border = "3px solid transparent";

    document.getElementById('score').innerHTML = "Current Total: 0";
    document.getElementById('roll').innerHTML = "Roll || Rolls Left: 3";
    rollsleft = 3;
}